
#include <stdio.h>
#define TAM 5

void exibirTabuleiro(char tabuleiro[TAM][TAM]) {
    printf("\n  ");
    for (int i = 0; i < TAM; i++) {
        printf("%d ", i);
    }
    printf("\n");

    for (int i = 0; i < TAM; i++) {
        printf("%d ", i);
        for (int j = 0; j < TAM; j++) {
            printf("%c ", tabuleiro[i][j]);
        }
        printf("\n");
    }
}

void inicializarTabuleiro(char tabuleiro[TAM][TAM]) {
    for (int i = 0; i < TAM; i++) {
        for (int j = 0; j < TAM; j++) {
            tabuleiro[i][j] = '~'; // Mar
        }
    }
}

void ataqueSimples(char tabuleiro[TAM][TAM], int x, int y) {
    if (x >= 0 && x < TAM && y >= 0 && y < TAM) {
        tabuleiro[x][y] = 'X';
    }
}

void ataqueCruz(char tabuleiro[TAM][TAM], int x, int y) {
    ataqueSimples(tabuleiro, x, y);
    ataqueSimples(tabuleiro, x-1, y);
    ataqueSimples(tabuleiro, x+1, y);
    ataqueSimples(tabuleiro, x, y-1);
    ataqueSimples(tabuleiro, x, y+1);
}

int main() {
    char tabuleiro[TAM][TAM];
    inicializarTabuleiro(tabuleiro);

    int x, y;
    exibirTabuleiro(tabuleiro);

    printf("\nDigite a linha e coluna para ataque simples: ");
    scanf("%d %d", &x, &y);
    ataqueSimples(tabuleiro, x, y);
    exibirTabuleiro(tabuleiro);

    printf("\nDigite a linha e coluna para ataque em cruz: ");
    scanf("%d %d", &x, &y);
    ataqueCruz(tabuleiro, x, y);
    exibirTabuleiro(tabuleiro);

    return 0;
}
