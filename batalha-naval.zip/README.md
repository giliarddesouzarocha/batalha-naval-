
# Jogo de Batalha Naval - Oceanic Games

## 🎯 Descrição
Projeto desenvolvido para a disciplina de Linguagem de Programação C, com o objetivo de criar um jogo de Batalha Naval, implementando matrizes e vetores, além de habilidades especiais que afetam áreas do tabuleiro.

## 🚀 Funcionalidades
- ✅ Ataque Simples
- ✅ Ataque em Cruz (atinge célula alvo + cima, baixo, esquerda e direita)
- 🔜 Pode ser expandido para outros formatos (cone, octaedro, etc.)

## 🛠️ Tecnologias
- Linguagem C
- IDEs: CodeBlocks, Dev C++ ou qualquer compilador C

## 💻 Como executar
1. Clone este repositório:
```
git clone https://github.com/giliarddesouzarocha/batalha-naval.git
```
2. Abra o arquivo `batalha_naval.c` em sua IDE de preferência.
3. Compile e execute o programa.

## 👨‍💻 Autor
- **Giliard de Souza Rocha**
